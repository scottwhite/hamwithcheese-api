module.exports = {
  aws: {
    accessKeyId:'AKIAJ6UAJPEEXMESF7QA',
    secretAccessKey:'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',
    bucket:'ham-with-cheese',
    region:'us-east-1'
  }
}
